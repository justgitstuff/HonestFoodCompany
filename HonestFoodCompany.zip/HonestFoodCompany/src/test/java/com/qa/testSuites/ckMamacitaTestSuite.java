package com.qa.testSuites;

import org.testng.annotations.Test;

import com.qa.tests.reusableMethods;
import com.qa.util.TestBase;

public class ckMamacitaTestSuite extends TestBase {
	
	@Test
	public void validateCheckOut() throws Exception {
		reusableMethods reusableMethods = new reusableMethods();
		reusableMethods.checkOut();
		
		
	}

}
