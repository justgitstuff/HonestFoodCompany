package com.qa.tests;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import com.qa.util.TestBase;
import com.qa.util.TestUtil;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.util.Reporter;

public class reusableMethods extends TestBase {

//	@FindBy(locator="xpath=//a[@href='/speisekarte/noaddress/']")
//	public WebElement linkMamacita;
//	@FindBy(locator="xpath=//button[@class='agree-cookie']")
//	public WebElement agreeCookie;

	public WebDriver driver;

	public void checkOut() throws Exception {

		WebDriver driver;
		TestBase.init();
		System.setProperty("webdriver.chrome.driver", "server/chromedriver");
		driver = new ChromeDriver();

		driver.get(prop.getProperty("Weburl"));
		driver.manage().window().maximize();
		Reporter.log("Navigating to " + driver.getCurrentUrl(), MessageTypes.Pass);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		
		
		WebElement acceptCookie = driver.findElement(By.xpath(TestUtil.sAcceptCookie));
		Assert.assertEquals(acceptCookie.isEnabled(), true);
		Reporter.log("Cookies accepted", MessageTypes.Pass);
		acceptCookie.click();
		
		WebElement linkMamacita = driver.findElement(By.xpath(TestUtil.sLinkMamacita));
		js.executeScript("window.scrollBy(0,550)");
		Assert.assertEquals(linkMamacita.isEnabled(), true);
		js.executeScript("arguments[0].click();", linkMamacita);
		Reporter.log("Mamacita vendor chosen", MessageTypes.Pass);
		
		Thread.sleep(5000);
		WebElement buttonAddress = driver.findElement(By.xpath(TestUtil.setAddress));
		Assert.assertEquals(buttonAddress.isEnabled(), true);
		js.executeScript("arguments[0].click();", buttonAddress);
		Reporter.log("Address selection", MessageTypes.Pass);
		
		Thread.sleep(2000);
		WebElement textAddress = driver.findElement(By.xpath(TestUtil.textAddress));
		Assert.assertEquals(textAddress.isEnabled(), true);
		textAddress.sendKeys(TestUtil.userAddress);
		Reporter.log("Address selection : " + TestUtil.userAddress, MessageTypes.Pass);
		
		WebElement buttonSubmit = driver.findElement(By.xpath(TestUtil.addressSubmit));
		Assert.assertEquals(buttonSubmit.isEnabled(), true);
		js.executeScript("arguments[0].click();", buttonSubmit);
		Reporter.log("Address selected and Confirmed", MessageTypes.Pass);
		
		Thread.sleep(3000);
		WebElement secondDish = driver.findElement(By.xpath(TestUtil.secondDish));
		Assert.assertEquals(secondDish.isEnabled(), true);
		js.executeScript("arguments[0].click();", secondDish);
		Reporter.log("Dish Selection button : " + secondDish.getText(), MessageTypes.Pass);
		
		Thread.sleep(4000);
		WebElement addOns = driver.findElement(By.xpath(TestUtil.oneAddOn));
		Assert.assertEquals(addOns.isEnabled(), true);
		js.executeScript("arguments[0].click();", addOns);
		Reporter.log("AddOn Selected : " + addOns.getText(), MessageTypes.Pass);
		
		WebElement confirmSelection = driver.findElement(By.xpath(TestUtil.selectConfirm));
		Assert.assertEquals(confirmSelection.isEnabled(), true);
		js.executeScript("arguments[0].click();", confirmSelection);
		Reporter.log("Final Selection Submit", MessageTypes.Pass);
		
		Thread.sleep(5000);
		WebElement checkOutSuccess = driver.findElement(By.xpath(TestUtil.checkOutConfirmation));
		Assert.assertEquals(checkOutSuccess.isEnabled(), true);
		Reporter.log("Check out successful", MessageTypes.Pass);
		driver.close();
		Reporter.log("Closing driver instance", MessageTypes.Pass);

	}

}
