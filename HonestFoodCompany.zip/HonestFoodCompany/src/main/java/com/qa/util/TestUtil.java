package com.qa.util;

public class TestUtil {
	public final static String sAcceptCookie = "//button[@class='agree-cookie']";
	public final static String sLinkMamacita = "//a[@href='/speisekarte/noaddress/']";
	public final static String setAddress = "//*[@id='customer_address_container']/a";
	public final static String textAddress = "//*[@id='address-input']";
	public final static String userAddress = "Semperstraße 44, 1180 Wien, Austria";
	public final static String addressSubmit = "//input[@class='btn--honest blattgold--form-banner-submit']";
	public final static String secondDish = "(//button[@class='buybox--button--image-overlay'])[2]";
	public final static String oneAddOn = "(//*[@class='label-text'])[1]";
	public final static String selectConfirm = "//*[@class='btn is--primary']";
	public final static String checkOutConfirmation = "//*[@class='icon--element icon--check']";
	
}
